<?php
	$content = array();
	
	$content['main-title'] = "La référence en CAO tôlerie";

?>