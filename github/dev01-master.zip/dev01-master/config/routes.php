<?php
	define("CONTROLLERS",$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."controllers");
	define("VIEWS",$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."views");
?>