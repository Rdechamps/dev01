
<?php
	include("../static/lang/fr/lang-fr.php");
?>
<div class="more-container">
	<a class="close-toggle" href="#" onClick="$('.toggle-container').css('left','100%;')">FERMER</a>
	<h2><?php echo $content['more-catalCAD-title']; ?></h2>
    
    <div>
    	<p><?php echo $content['more-catalCAD-title']; ?></p>
    </div>
    <div>
    	<p><?php echo $_SESSION['lang']; echo $content['more-catalCAD-text-1']; ?></p>
    	<p><?php echo $content['more-catalCAD-text-2']; ?></p>
        <p><?php echo $content['more-catalCAD-text-3']; ?></p>
        <p><?php echo $content['more-catalCAD-text-4']; ?></p>
        <p><?php echo $content['more-catalCAD-text-5']; ?></p>
        <p><?php echo $content['more-catalCAD-text-6']; ?></p>
        <p><?php echo $content['more-catalCAD-text-7']; ?></p>
        <p><?php echo $content['more-catalCAD-text-8']; ?></p>
	</div>
    <div>
        <p><?php echo $content['more-catalCAD-text-9']; ?></p>
        <p><?php echo $content['more-catalCAD-text-10']; ?></p>
        <p><?php echo $content['more-catalCAD-text-11']; ?></p>
        <p><?php echo $content['more-catalCAD-text-12']; ?></p>
        <p><?php echo $content['more-catalCAD-text-13']; ?></p>
    </div>
</div>
